 <footer class="foo">
                <div class="col-lg-12">
                <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:21px; color: #fff; background-color: #092247; padding: 40px;"><b>Copyright of 2019 Infiniti Software Solutions Pvt Ltd</b></p>
                </div>
           
   </footer>
