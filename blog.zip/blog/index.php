<?php include 'includes/connection.php';
?>
<?php include 'includes/header.php';?>
        
   <?php include 'includes/navbar.php';?>
        
<div class="container">
<div class="col-lg-12">
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="allpostpics/ban3.png" alt="Los Angeles">
    </div>

    <div class="item">
      <img src="allpostpics/ad3.jpg" alt="New York">
    </div>
  </div>
<hr>
  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</div>        

    <div class="container">

        <div class="row">

        <div class="col-md-8">

<?php
$query = "SELECT * FROM posts WHERE status='published' ORDER BY updated_on DESC";
$run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
if (mysqli_num_rows($run_query) > 0) {
while ($row = mysqli_fetch_assoc($run_query)) {
  $post_title = $row['title'];
   $post_category = $row['category'];
  $post_id = $row['id'];
  $post_author = $row['author'];
  $post_date = $row['postdate'];
  $post_image = $row['image'];
  $post_content = $row['content'];
  $post_tags = $row['tag'];
  $post_updated_on= $row['updated_on'];
  $post_status = $row['status'];
  if ($post_status !== 'published') {
    echo "NO POST PLS";
  } else {

    ?>
            <div class="panel panel-info">
            <div class="color">
            <div class="panel-heading ">
            <p ><h2><?php echo $post_title; ?></h2></p>
            
            </div></div>
            <div class="panel-body">
          <hr><a href="publicposts.php?post=<?php echo $post_id; ?>">
          <img class="img-responsive img-rounded" src="allpostpics/<?php echo $post_image; ?>" alt="900 * 300"></a>
          <hr></div>
          <div class="panel-footer">
          <p style="font-family: 'Monotype Corsiva'; font-size:21px;"><?php echo substr($post_content, 0, 300) . '.........';?></p>
			<p><h3>by <?php echo $post_author; ?></h3></p>
            <p><span class="glyphicon glyphicon-time"></span>&nbsp;Posted on <?php echo $post_updated_on; ?></p>
            <a href="publicposts.php?post=<?php echo $post_id; ?>"><button type="button" class="btn btn-primary">Read More<span class="glyphicon glyphicon-chevron-right"></span></button></a>
	        <a href="https://web.whatsapp.com/send?text=www.infinitisoftware.net" data-action="share/whatsapp/share" class="btn btn-success"><span class="glyphicon glyphicon-share-alt"></span> Share</a>
			</div>
			</div>
			<hr>
            <?php }}}?>

        
          </div>
	        
	        <div class="col-md-4">

               <?php include 'includes/sidebar.php';?>

	        </div>
	        
      
         </div>
	  </div>
        <?php include 'includes/footer.php';?>
   
 
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
<style type="text/css">
  .color
  {
    background:#092247;
    color: white;
  }

</style>


</body>
</html>