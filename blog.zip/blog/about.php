<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-8 text-justify">
            <h1 class="page-header text-primary"><b>About | Us </b></h1>
             Hi there!
            <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Never doubt that a small group of thoughtful, committed people can change the world.Indeed, it is the only thing that ever has." - Margaret Meade.
            <br><br>
			Our endeavor has been to create world class travel and aviation technology solutions.We believe in building strong partnerships with our customers to ensure that we are able to deliver a robust and cost efficient solution to them.
	<br><br>
Our journey has been an exciting and rewarding one. We pride ourselves in developing innovative travel technology products, from building India`s first retail travel portal Ghumo.com to India`s first web based business travel solution Atyouprice.net, our mission has remained unchanged.
	<br><br>
We are fortunate to have an opportunity to serve over 230 corporates, travel agencies and airlines across the globe. Today Team Infiniti is spread across four locations in India with over 250 highly motivated and experienced travel technology specialists supporting our vision and customers.


			
			
		


            <br><br><br><br>



           
         <h2><b>Our Investors</b></h2>
           <br>

Infiniti is funded by Mumbai Angels <a>(www.mumbaiangels.com)</a>, a group of experienced professionals-turned-investors. 
Mumbai Angels, which has as its members CEOs, CFOs, senior lawyers and IT experts with experience in Silicon Valley, California, backs start-ups and young companies
           <br><br><br>

 


          <b> Investor Relations <br>
           Gautam Ramanujan <br>
           Chief Commercial Officer<br>
           9920984120 |<a>gautam@infinitisoftware.net</a></b><br>
           <br>
           <br>



        </div>

  
</div>
</div>
</div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>