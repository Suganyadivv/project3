
<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-12">
            <h2 class="page-header">SEARCH RESULTS</h2>
            <?php
if (isset($_POST['submit'])) {
	$search = htmlspecialchars(mysqli_real_escape_string($conn, $_POST["search"]));
	if(empty($search)) {
		header('location: index.php');
	}
	$query = "SELECT * FROM posts WHERE tag LIKE '%$search%' AND status='published' OR category LIKE '%$search%' ";
	$search_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
	$count = mysqli_num_rows($search_query);
	if ($count == 0) {
		echo "<h1>Sorry, no result found for your query</h1>";
	} else {
		while ($row = mysqli_fetch_array($search_query)) {
			$post_title = $row['title'];
			$post_category= $row['category'];
			$post_id = $row['id'];
			$post_author = $row['author'];
			$post_date = $row['postdate'];
			$post_image = $row['image'];
			$post_content = $row['content'];
			$post_tags = $row['tag'];
			$post_status = $row['status'];
			$post_updated_on= $row['updated_on'];
			?>
		<!-- Post Area-->
				<div class="panel panel-info">
				<div class="color">
				<div class="panel-heading ">
	        	<p><h2><?php echo $post_title; ?></a></h2></p>
	        	<p><h3>by <?php echo $post_author; ?></a></h3></p></div>
				<p><span class="glyphicon glyphicon-time"></span>&nbsp;Posted on <?php echo $post_updated_on; ?></p>
				</div>
	        	<div class="panel-body">
	        	
	        	<hr>
	        	<img class="img-responsive img-rounded" src="allpostpics/<?php echo $post_image; ?>" alt="900 * 300">
	        	<hr>
	        	<p style="font-family: 'Monotype Corsiva'; font-size:21px;"><?php echo substr($post_content, 0, 300) . '.........'; ?></p>
	        </div>
	        <div class="panel-footer">
	        		<a href="publicposts.php?post=<?php echo $post_id; ?>"><button type="button" class="btn btn-primary">Read More<span class="glyphicon glyphicon-chevron-right"></span></button></a></div></div>
	        	<hr>
	        	<!-- Post Area -->
	        	<?php }
	}
}
else {
	header("location: index.php");
}
?>

<style type="text/css">
  .color
  {
    background:#092247;
    color: white;
  }

</style>
	        	
	        	
	        </div>
	        <!-- Page Content -->
	        <!-- Side Content -->

	        <!-- Sde Content -->
        </div>

        <!-- Footer -->
        <?php include 'includes/footer.php';?>
        <!-- Footer -->
    </div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>